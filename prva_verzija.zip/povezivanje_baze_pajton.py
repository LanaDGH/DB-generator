import sqlite3

#prva verzija programa - povezivanje baze podataka, kreiranje tabele

#konekcija sa bazom podataka
def connect():
    try:
        conn =  sqlite3.connect("baza.db")
        print('Uspešno konektovano')
        return conn
    except sqlite3.Error as e:
        print(e)

#diskonektovanje od baze podataka
def disconnect(conn):
    try:
        conn.close()
        print('Uspešno diskonektovano')
    except sqlite3.Error as e:
        print(e)

#obrada unetih podataka; pre nego što se kreira tabela,
#cilj je da pretvoriti vrednosti nizova u gotove stringove
#koji se mogu direktno ubaciti u string sql (v. kreiranje_tabele)
def obrada(conn, broj_kolona, tipovi_kolona, not_null):

    #"ispravljanje" niza tipovi_kolona - v. uputstvo u main
    for i in range(broj_kolona):
        match tipovi_kolona[i]:
            case 1:
                tipovi_kolona[i] = 'INTEGER'
            case 2:
                tipovi_kolona[i] = 'FLOAT'
            case 3:
                tipovi_kolona[i] = 'DATETIME'
            case 4:
                tipovi_kolona[i] = 'TEXT'
            case 5:
                tipovi_kolona[i] = 'BINARY'

    #"ispravljanje" niza not_null - v. uputstvo u main
    for i in range(broj_kolona):
        if not_null[i] == 1:
            not_null[i] = 'NOT NULL'
        elif not_null[i] == 0:
            not_null[i] = ''
            
    return tipovi_kolona, not_null

def kreiranje_tabele(conn, naziv_tabele, broj_kolona, nazivi_kolona, tipovi_kolona, not_null):

    #sastavljanje sql upita u string
    sql = f'CREATE TABLE {naziv_tabele} (\n'
    for i in range(broj_kolona):
        stg = f'{nazivi_kolona[i]} {tipovi_kolona[i]} {not_null[i]}, \n'
        sql = sql+stg
    st = f'PRIMARY KEY({nazivi_kolona[0]}))'
    sql = sql+st

    #prosleđivanje sql upita
    try:
        cursor =conn.cursor()
        cursor.execute(sql)
        cursor.close()
    except sqlite3.Error as e:
        print(e)
    

def main():
    #konektovanje na bazu podataka
    conn = connect()

    #unos naziva tabele
    naziv_tabele = input('Naziv tabele: ')

    #unos broja kolona u tabeli
    broj_kolona = int(input('Broj kolona: '))
    nazivi_kolona = []
    tipovi_kolona = []
    not_null = []
    default = []

    #kratko uputstvo za korisnika
    print('''Uputstvo!
Prva kolona je podrazumevano primarni ključ. Obratite pažnju kojim redosledom unosite nazive kolona.
Ako su vrednosti u koloni tipa:
    1. ceo broj (INTEGER) upisati 1
    2. decimalno izražen broj (FLOAT) upisati 2
    3. datum i vreme (DATETIME) upisati 3
    4. tekst (TEXT) upisati 4
    5. binaran (BINARY) upisati 5''')

    #Unos naziva kolona, njihovih tipova, NOTNULL ograničenja
    for i in range(broj_kolona):
        a = input(f'Naziv {i+1}-te kolone: ')
        b = input(f'Tip vrednosti u koloni - upisati broj kao u uputstvu: ')
        c = input(f'Ako vrednosti u koloni ne mogu biti NULL, upisati 1. Ako je ipak dozvoljeno, upisati 0. ')
        
        #dodavanje unetih vrednosti u nizove koji će se prosleđivati dalje u funkciju
        nazivi_kolona.append(a)
        tipovi_kolona.append(int(b))
        not_null.append(int(c))

    #izvršavanje - obrada unetih podataka, kreiranje tabele
    tk, nn = obrada(conn, broj_kolona, tipovi_kolona, not_null)
    kreiranje_tabele(conn, naziv_tabele, broj_kolona, nazivi_kolona, tk, nn)
    
    #Diskonektovanje
    disconnect(conn)
    
if __name__ == '__main__':
    main()
    
